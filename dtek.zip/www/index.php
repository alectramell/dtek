<?php
	$xtitle = 'www.DiningTek.com';
?>
<html>
<head>
<title>
<?php echo $xtitle; ?> 
</title>
<link type="text/css" rel="stylesheet" href="css/main.css">
</head>
<body>

<div id="titleBox">
<font class="headerI">DININGTEK</font>
<br />
<font class="headerII">Food and Dining Business Systems </font>
<font 
style="position:relative;font-family:monospace;font-size:18;color:#c4c4c4;vertical-margin:middle;">&reg;</font>
</div>

<div id="dashBoard">
</div>

</body>
</html>
