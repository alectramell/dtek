#!/bin/bash

clear

XURL="localhost:8888"

clear

php -S $XURL
