#!/bin/bash

clear

XFILE="$1"

clear

for i in $(seq 1 $3)
do
	cat $XFILE | sed "$i!d" | rev | xxd -p -r >> $2
	echo -e "\n" >> $2
	sleep 0.5
done

sleep 2.5

clear

cat $2

sleep 0.5
