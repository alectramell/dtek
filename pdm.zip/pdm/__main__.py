import os
import sys
import platform

OSname = str(platform.system())

if OSname == "Linux":

	def clear():
	
		import os
		os.system('clear')
else:

	def clear():

		import os
		os.system('clear')

xvar = sys.argv[1]

xvar = str(xvar)

xout = str(xvar.encode('hex'))

output = str(xout[::-1])

print(output)
