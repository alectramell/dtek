#!/bin/bash

clear

zip -r pdm.zip pdm/* *.sh

sleep 2.5

clear

echo "pdm.zip successfully created!"
